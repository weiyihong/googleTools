window.Polymer = window.Polymer || {};
window.Polymer.dom = 'shadow';
